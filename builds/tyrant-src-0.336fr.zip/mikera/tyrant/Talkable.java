//
// Interface for objects than can be talked to
//
package mikera.tyrant;

public interface Talkable {
	public void talk(Thing t);
}